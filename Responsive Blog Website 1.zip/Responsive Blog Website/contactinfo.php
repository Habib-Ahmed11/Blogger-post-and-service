<?php
// Database connection parameters
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "username"; // Change this to your database username
$password = "password"; // Change this to your database password
$dbname = "mycontact"; // Change this to your database name

// Create connection
$conn = new mysqli('localhost', 'root', 'root1234', 'mycontact');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone_no = $_POST['phone_no'];
    $email = $_POST['email'];
    $txtarea = $_POST['txtarea'];
    
    // Prepare and execute SQL query to insert data into the database
    $sql = "INSERT INTO info (first_name, last_name, phone_no, email, txtarea) 
            VALUES ('$first_name', '$last_name', '$phone_no', '$email', '$txtarea')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
